import os
for i in range(96):
    # pool_x
    os.system('~/software/art_bin_MountRainier/art_illumina -ss HS25 -sam -i ../pool/X' +str(i) +  
          '.fasta -p -l 150 -f 50 -m 500 -s 100 -o X' + str(i)+'_')
    # pool_y.  
    os.system('~/software/art_bin_MountRainier/art_illumina -ss HS25 -sam -i ../pool/Y' +str(i) +  
          '.fasta -p -l 150 -f 50 -m 500 -s 100 -o Y' + str(i)+'_')
