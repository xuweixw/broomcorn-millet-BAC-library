from optparse import OptionParser

parser = OptionParser()
parser.add_option('-f','--fasta',dest='fasta')
parser.add_option('-p','--psl',dest='psl')
parser.add_option('-o','--output',dest='output_file')
(options,args) = parser.parse_args()

## 输入blat比对信息
import pandas as pd
blat = pd.read_csv(options.psl, header=None, sep='\t', usecols=[0,8,9,10,11,12,13,14,15,16])

## 输入原始fasta文件
from HTSeq import FastaReader
contigs = FastaReader(options.fasta)

## 将FastaReader转换成字典
contigs_dict = {}
for i in contigs:
    contigs_dict[i.name] = i

## 判断正负链，截取BES
for i in range(blat.shape[0]):
    id = blat.iloc[i,2]
    strand = blat.iloc[i,1]
    seq = contigs_dict[id]
    trimed_seq =None
    if strand == '+' :
        trimed_seq = seq[(blat.iloc[i,5]+1):]
    elif strand == '-' :
        trimed_seq = seq[:(blat.iloc[i,4])].get_reverse_complement()
    contigs_dict[id] = trimed_seq

## 输出BES
with open(options.output_file,'w+') as file:
    for i in contigs_dict:
        contigs_dict[i].name = i
        if len(contigs_dict[i]) > 0 :
            contigs_dict[i].write_to_fasta_file(file)
