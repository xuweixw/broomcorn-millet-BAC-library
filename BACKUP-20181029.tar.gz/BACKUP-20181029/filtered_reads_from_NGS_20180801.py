from HTSeq import *
import numpy as np
import pandas as pd
import Bio
from Bio import SeqIO
from optparse import OptionParser


class Read(SequenceWithQualities):
    def __repr__(self):
        return "%s\t%s\t%s\n" % (self.name, self.seq.decode(), len(self.seq))

class ReadSet:
    def __init__(self, reads=None):
        if reads == None:
            self.reads = []
        elif isinstance(reads, FastqReader):
            self.reads = [Read(i[0].encode(),i[1],i[2].encode(),i[3])for i in reads]
        else:
            raise TypeError
    def __repr__(self):
        if len(self.reads) <= 10:
            return ("Name\tSeq\tLength\n" + "%s") %("".join([i.__repr__() for i in self.reads[:]]))
        else:
            return ("Name\tSeq\tLength\n" + "%s\n......\n%s") % ("".join([i.__repr__() for i in self.reads[:5]]), \
                                                                 "".join([i.__repr__() for i in self.reads[-5:]]))
    def __getitem__(self, index):
        return self.reads[index]
    
    def append(self, read):
        self.reads.append(read)
    
    def write_to_fastq(self, file_name):
        if len(self.reads) != 0 :
            file_handle = open(file_name, 'w+')
            for i in self.reads:
                i.write_to_fastq_file(file_handle)
            file_handle.close()
            print('It is saved to %s, OK.' % (file_name))
        else:
            print('Nothing need to save.')

class PERead:
    def __init__(self, name, r1, qual1, r2, qual2):
        self.name = name
        self.R1 = Read(name, r1, qual1)
        self.R2 = Read(name, r2, qual2)
    


class PEReadSet:
    pass

def FastqReader_To_ReadSet(file_):
    fastq_file = FastqReader(file_, raw_iterator=True)
    return ReadSet(fastq_file)


def seed_search(R,T):
    score_array = np.zeros((len(T)+1,len(R)+1),dtype='int')
    for i in range(len(T)+1):
        score_array[i,0] =0
        
    for j in range(1,len(R)+1):
        score_array[0,j] = 0
        
    for i in range(1,len(T)+1):
        for j in range(1,len(R)+1):
            if T[i-1] == R[j-1]:
                align = score_array[i-1,j-1] + 1
            else:
                align = score_array[i-1,j-1] + 0
            
            insert = score_array[i-1,j] -1
            delete = score_array[i,j-1] -1
            score_array[i,j] = max(align,insert,delete)
            
    max_score = max(score_array[-1])
    
    return len(T) - max_score # return minimum edit-distance


def isOverlap(read,seed,e):      #the constant edit distance
    rv_seed = str(Bio.Seq.Seq(seed).reverse_complement())
    
    if seed_search(R=read,T=seed) <= e or seed_search(R=read,T=rv_seed) <= e:
        return True
    else:
        return False







parser = OptionParser()
parser.add_option('-v','--vector',dest='vector_end')
parser.add_option('-1','--read1',dest='R1_raw_filename')
parser.add_option('-2','--read2',dest='R2_raw_filename')
parser.add_option('-a','--output_read1',dest='R1_filered_filename')
parser.add_option('-b','--output_read2',dest='R2_filered_filename')
parser.add_option('-l','--length',type='int',default=20,dest='overlap_length',help='the min of overlapping length.')
parser.add_option('-e','--edit',type='int',default=2,dest='edit_distance',help='the max edit distance')
(options,args) = parser.parse_args()




#R1_raw_filename = '../demo-data/demo.fastq'
#R2_raw_filename = '../demo-data/demo.fastq'
#overlap_length = 6
#edit_distance = 2

#R1_filered_filename = '../demo-data/R1_xxxx.fastq'
#R2_filered_filename = '../demo-data/R2_xxxx.fastq'

#pIndigoBAC536S_end = 'ACGATCGATCATTACGATCTAGC'

# the Sequence of BAC vector end
pIndigoBAC536S_end =  [i for i in FastaReader(options.vector_end) ][0].seq.decode()

R1_FastqReader = FastqReader(options.R1_raw_filename)
R1_iterator = R1_FastqReader.__iter__()


R2_FastqReader = FastqReader(options.R2_raw_filename)
R2_iterator = R2_FastqReader.__iter__()

R1_ReadSet = ReadSet()
R2_ReadSet = ReadSet()

reads_number = 0

try:
    while True:
        R1_SequenceWithQualities = next(R1_iterator)
        R2_SequenceWithQualities = next(R2_iterator)
        if isOverlap(R1_SequenceWithQualities.seq.decode(), seed=pIndigoBAC536S_end[-options.overlap_length:], e=options.edit_distance) or \
           isOverlap(R2_SequenceWithQualities.seq.decode(), seed=pIndigoBAC536S_end[-options.overlap_length:], e=options.edit_distance):
            R1_ReadSet.append(R1_SequenceWithQualities)
            R2_ReadSet.append(R2_SequenceWithQualities)
        reads_number += 1
        print('\r%s paried end reads has been processed\t\t' % (reads_number), end='', flush=True)
except StopIteration:
    pass

R1_ReadSet.write_to_fastq(options.R1_filered_filename)
R2_ReadSet.write_to_fastq(options.R2_filered_filename)
