
# coding: utf-8

# ### BAC文库模拟构建
#     从fasta格式文件中读取参考基因组序列，作为DNA的来源。在基因组序列上随机产生一个基点，作为BAC的一端，然后再随机生成BAC长度，将基点与长度的和作为BAC的另一端。按照这种方法生成大量的BAC序列，并给每一个BAC序列赋一个唯一的识别码（ID）。

# #### 从fasta中读取序列

# In[1]:
import random
import numpy as np
import re
import string
import pandas as pd
import os
from optparse import OptionParser

parser = OptionParser()
parser.add_option('-i','--input',dest='input_file')
#parser.add_option('-o','--output',dest='output_file')
#parser.add_option('-e','--enzyme',dest='enzyme')

(options,args) = parser.parse_args()


BAC_front = ('tctctctgaaaatcgactggatcatagagcgttaccagctgcctcaaagttaccagcgtatgcctgacttccgccgccgc'
'ttcctgcaggtctgtgttaatgagatcaacagcagaactccaatgcgcctctcatacattgagaaaaagaaaggccgcca'
'gacgactcatatcgtattttccttccgcgatatcacttccatgacgacaggatagtctgagggttatctgtcacagattt'
'gagggtggttcgtcacatttgttctgacctactgagggtaatttgtcacagttttgctgtttccttcagcctgcatggat'
'tttctcatactttttgaactgtaatttttaaggaagccaaatttgagggcagtttgtcacagttgatttccttctctttc'
'ccttcgtcatgtgacctgatatcgggggttagttcgtcatcattgatgagggttgattatcacagtttattactctgaat'
'tggctatccgcgtgtgtacctctacctggagtttttcccacggtggatatttcttcttgcgctgagcgtaagagctatct'
'gacagaacagttcttctttgcttcctcgccagttcgctcgctatgctcggttacacggctgcggcgagcgctagtgataa'
'taagtgactgaggtatgtgctcttcttatctccttttgtagtgttgctcttattttaaacaactttgcggttttttgatg'
'actttgcgattttgttgttgctttgcagtaaattgcaagatttaataaaaaaacgcaaagcaatgattaaaggatgttca'
'gaatgaaactcatggaaacacttaaccagtgcataaacgctggtcatgaaatgacgaaggctatcgccattgcacagttt'
'aatgatgacagcccggaagcgaggaaaataacccggcgctggagaataggtgaagcagcggatttagttggggtttcttc'
'tcaggctatcagagatgccgagaaagcagggcgactaccgcacccggatatggaaattcgaggacgggttgagcaacgtg'
'ttggttatacaattgaacaaattaatcatatgcgtgatgtgtttggtacgcgattgcgacgtgctgaagacgtatttcca'
'ccggtgatcggggttgctgcccataaaggtggcgtttacaaaacctcagtttctgttcatcttgctcaggatctggctct'
'gaaggggctacgtgttttgctcgtggaaggtaacgacccccagggaacagcctcaatgtatcacggatgggtaccagatc'
'ttcatattcatgcagaagacactctcctgcctttctatcttggggaaaaggacgatgtcacttatgcaataaagcccact'
'tgctggccggggcttgacattattccttcctgtctggctctgcaccgtattgaaactgagttaatgggcaaatttgatga'
'aggtaaactgcccaccgatccacacctgatgctccgactggccattgaaactgttgctcatgactatgatgtcatagtta'
'ttgacagcgcgcctaacctgggtatcggcacgattaatgtcgtatgtgctgctgatgtgctgattgttcccacgcctgct'
'gagttgtttgactacacctccgcactgcagtttttcgatatgcttcgtgatctgctcaagaacgttgatcttaaagggtt'
'cgagcctgatgtacgtattttgcttaccaaatacagcaatagtaatggctctcagtccccgtggatggaggagcaaattc'
'gggatgcctggggaagcatggttctaaaaaatgttgtacgtgaaacggatgaagttggtaaaggtcagatccggatgaga'
'actgtttttgaacaggccattgatcaacgctcttcaactggtgcctggagaaatgctctttctatttgggaacctgtctg'
'caatgaaattttcgatcgtctgattaaaccacgctgggagattagataatgaagcgtgcgcctgttattccaaaacatac'
'gctcaatactcaaccggttgaagatacttcgttatcgacaccagctgccccgatggtggattcgttaattgcgcgcgtag'
'gagtaatggctcgcggtaatgccattactttgcctgtatgtggtcgggatgtgaagtttactcttgaagtgctccggggt'
'gatagtgttgagaagacctctcgggtatggtcaggtaatgaacgtgaccaggagctgcttactgaggacgcactggatga'
'tctcatcccttcttttctactgactggtcaacagacaccggcgttcggtcgaagagtatctggtgtcatagaaattgccg'
'atgggagtcgccgtcgtaaagctgctgcacttaccgaaagtgattatcgtgttctggttggcgagctggatgatgagcag'
'atggctgcattatccagattgggtaacgattatcgcccaacaagtgcttatgaacgtggtcagcgttatgcaagccgatt'
'gcagaatgaatttgctggaaatatttctgcgctggctgatgcggaaaatatttcacgtaagattattacccgctgtatca'
'acaccgccaaattgcctaaatcagttgttgctcttttttctcaccccggtgaactatctgcccggtcaggtgatgcactt'
'caaaaagcctttacagataaagaggaattacttaagcagcaggcatctaaccttcatgagcagaaaaaagctggggtgat'
'atttgaagctgaagaagttatcactcttttaacttctgtgcttaaaacgtcatctgcatcaagaactagtttaagctcac'
'gacatcagtttgctcctggagcgacagtattgtataagggcgataaaatggtgcttaacctggacaggtctcgtgttcca'
'actgagtgtatagagaaaattgaggccattcttaaggaacttgaaaagccagcaccctgatgcgaccacgttttagtcta'
'cgtttatctgtctttacttaatgtcctttgttacaggccagaaagcataactggcctgaatattctctctgggcccactg'
'ttccacttgtatcgtcggtctgataatcagactgggaccacggtcccactcgtatcgtcggtctgattattagtctggga'
'ccacggtcccactcgtatcgtcggtctgattattagtctgggaccacggtcccactcgtatcgtcggtctgataatcaga'
'ctgggaccacggtcccactcgtatcgtcggtctgattattagtctgggaccatggtcccactcgtatcgtcggtctgatt'
'attagtctgggaccacggtcccactcgtatcgtcggtctgattattagtctggaaccacggtcccactcgtatcgtcggt'
'ctgattattagtctgggaccacggtcccactcgtatcgtcggtctgattattagtctgggaccacgatcccactcgtgtt'
'gtcggtctgattatcggtctgggaccacggtcccacttgtattgtcgatcagactatcagcgtgagactacgattccatc'
'aatgcctgtcaagggcaagtattgacatgtcgtcgtaacctgtagaacggagtaacctcggtgtgcggttgtatgcctgc'
'tgtggattgctgctgtgtcctgcttatccacaacattttgcgcacggttatgtggacaaaatacctggttacccaggccg'
'tgccggcacgttaaccgggctgcatccgatgcaagtgtgtcgctgtcgactagggataacagggtaatcgtcagcgggtg'
'ttggcgggtgtcggggctggcttaactatgcggcatcagagcagattgtactgagagtgcaccatatgcggtgtgaaata'
'ccgcacagatgcgtaaggagaaaataccgcatcaggcgccattcgccattcagctgcgcaactgttgggaagggcgatcg'
'gtgcgggcctcttcgctattacgccagctggcgaaagggggatgtgctgcaaggcgattaagttgggtaacgccagggtt'
'ttcccagtcacgacgttgtaaaacgacggccagtgaattgtaatacgactcactatagggcgaattcgagctcggtaccc'
'ggggatcctctagagtcgacctgcaggcatgc')

BAC_behind = ('aagcttgtctccctatagtgagtcgtattagagcttggcgtaatcatggtcatagctgtttcctgtgtgaaattgttat'
'ccgctcacaattccacacaacatacgagccggaagcataaagtgtaaagcctggggtgcctaatgagtgagctaactcac'
'attaattgcgttgcgctcactgcccgctttccagtcgggaaacctgtcgtgccagctgcattaatgaatcggccaacgcg'
'aacccctattaccctgttatccctagtcgaccaattctcatgtttgacagcttatcatcgaatttctgccattcatccgc'
'ttattatcacttattcaggcgtagcaaccaggcgtttaagggcaccaataactgccttaaaaaaattacgccccgccctg'
'ccactcatcgcagtactgttgtaattcattaagcattctgccgacatggaagccatcacaaacggcatgatgaacctgaa'
'tcgccagcggcatcagcaccttgtcgccttgcgtataatatttgcccatggtgaaaacgggggcgaagaagttgtccata'
'ttggccacgtttaaatcaaaactggtgaaactcacccagggattggctgagacgaaaaacatattctcaataaacccttt'
'agggaaataggccaggttttcaccgtaacacgccacatcttgcgaatatatgtgtagaaactgccggaaatcgtcgtggt'
'attcactccagagcgatgaaaacgtttcagtttgctcatggaaaacggtgtaacaagggtgaacactatcccatatcacc'
'agctcaccgtctttcattgccatacggaatttcggatgagcattcatcaggcgggcaagaatgtgaataaaggccggata'
'aaacttgtgcttatttttctttacggtctttaaaaaggccgtaatatccagctgaacggtctggttataggtacattgag'
'caactgactgaaatgcctcaaaatgttctttacgatgccattgggatatatcaacggtggtatatccagtgatttttttc'
'tccattttagcttccttagctcctgaaaatctcgataactcaaaaaatacgcccggtagtgatcttatttcattatggtg'
'aaagttggaacctcttacgtgccgatcaacgtctcattttcgccaaaagttggcccagggcttcccggtatcaacaggga'
'caccaggatttatttattctgcgaagtgatcttccgtcacaggtatttattcgcgataagctcatggagcggcgtaaccg'
'tcgcacaggaaggacagagaaagcgcggatctgggaagtgacggacagaacggtcaggacctggattggggaggcggttg'
'ccgccgctgctgctgacggtgtgacgttctctgttccggtcacaccacatacgttccgccattcctatgcgatgcacatg'
'ctgtatgccggtataccgctgaaagttctgcaaagcctgatgggacataagtccatcagttcaacggaagtctacacgaa'
'ggtttttgcgctggatgtggctgcccggcaccgggtgcagtttgcgatgccggagtctgatgcggttgcgatgctgaaac'
'aattatcctgagaataaatgccttggcctttatatggaaatgtggaactgagtggatatgctgtttttgtctgttaaaca'
'gagaagctggctgttatccactgagaagcgaacgaaacagtcgggaaaatctcccattatcgtagagatccgcattatta'
'atctcaggagcctgtgtagcgtttataggaagtagtgttctgtcatgatgcctgcaagcggtaacgaaaacgatttgaat'
'atgccttcaggaacaatagaaatcttcgtgcggtgttacgttgaagtggagcggattatgtcagcaatggacagaacaac'
'ctaatgaacacagaaccatgatgtggtctgtccttttacagccagtagtgctcgccgcagtcgagcgacagggcgaagcc'
'ctcgagtgagcgaggaagcaccagggaacagcacttatatattctgcttacacacgatgcctgaaaaaacttcccttggg'
'gttatccacttatccacggggatatttttataattattttttttatagtttttagatcttcttttttagagcgccttgta'
'ggcctttatccatgctggttctagagaaggtgttgtgacaaattgccctttcagtgtgacaaatcaccctcaaatgacag'
'tcctgtctgtgacaaattgcccttaaccctgtgacaaattgccctcagaagaagctgttttttcacaaagttatccctgc'
'ttattgactcttttttatttagtgtgacaatctaaaaacttgtcacacttcacatggatctgtcatggcggaaacagcgg'
'ttatcaatcacaagaaacgtaaaaatagcccgcgaatcgtccagtcaaacgacctcactgaggcggcatatagtctctcc'
'cgggatcaaaaacgtatgctgtatctgttcgttgaccagatcagaaaatctgatggcaccctacaggaacatgacggtat'
'ctgcgagatccatgttgctaaatatgctgaaatattcggattgacctctgcggaagccagtaaggatatacggcaggcat'
'tgaagagtttcgcggggaaggaagtggttttttatcgccctgaagaggatgccggcgatgaaaaaggctatgaatctttt'
'ccttggtttatcaaacgtgcgcacagtccatccagagggctttacagtgtacatatcaacccatatctcattcccttctt'
'tatcgggttacagaaccggtttacgcagtttcggcttagtgaaacaaaagaaatcaccaatccgtatgccatgcgtttat'
'acgaatccctgtgtcagtatcgtaagccggatggctcaggcatcgtctctctgaaaatcgactggatcatagagcgttac'
'cagctgcctcaaagttaccagcgtatgcctgacttccgccgccgcttcctgcaggtctgtgttaatgagatcaacagcag'
'aactccaatgcgcctctcatacattgagaaaaagaaaggccgccagacgactcatatcgtattttccttccgcgatatca'
'cttccatgacgacaggatagtctgagggttatctgtcacagatttgagggtggttcgtcacatttgttctgacctactga'
'gggtaatttgtcacagttttgctgtttccttcagcctgcatggattttctcatactttttgaactgtaatttttaaggaa'
'gccaaatttgagggcagtttgtcacagttgatttccttctctttcccttcgtcatgtgacctgatatcgggggttagttc'
'gtcatcattgatgagggttgattatcacagtttattactctgaattggctatccgcgtgtgtacctctacctggagtttt'
'tcccacggtggatatttcttcttgcgctgagcgtaagagctatctgacagaacagttcttctttgcttcctcgccagttc'
'gctcgctatgctcggttacacggctgcggcgagcgctagtgataataagtgactgaggtatgtgctcttcttatctcctt'
'ttgtagtgttgctcttattttaaacaactttgcggttttttgatgactttgcgattttgttgttgctttgcagtaaattg'
'caagatttaataaaaaaacgcaaagcaatgattaaaggatgttcagaatgaaactcatggaaacacttaaccagtgcata'
'aacgctggtcatgaaatgacgaaggctatcgccattgcacagtttaatgatgacagcccggaagcgaggaaaataacccg'
'gcgctggagaataggtgaagcagcggatttagttggggtttcttctcaggctatcagagatgccgagaaagcagggcgac'
'taccgcacccggatatggaaattcgaggacgggttgagcaacgtgttggttatacaattgaacaaattaatcatatgcgt')


def readGenome(filename):
    genome = ''
    with open(filename, 'r') as f:
        for line in f:
            if not line[0] == '>':
                genome += line.rstrip()    
    return genome


# 利用碱基序列填补N
def substitute_for_Ns(genome):
    BASES = 'ATCG'
    genome = list(genome)
    for i in range(len(genome)):
        if genome[i] == 'N':
            genome[i] = random.choice(BASES)
    return ''.join(genome)


def genome_dict_to_fasta(filename,dict):
    with open(filename,'w') as f:
        for i in dict:
            f.write(str('>' + i+'\n'))
            chr = dict[i]
            full_lines = len(chr) // 80 #计算整行数
            f.writelines([chr[i*80:(i+1)*80]+'\n' for i in range(full_lines)])
            f.writelines(chr[(full_lines*80):])


def find_neighbor(one,population):
        population.sort()
        for i in range(len(population)):
            if population[i] == one:
                left,right = population[i],population[i]
                break
            elif population[i] > one:
                left = population[i-1]
                right = population[i]
                break
            elif population[-1] < one:
                left,right = population[-1],population[-1]
                break
        return (left,right)

    
def alignment(pattern,text):
    P = re.compile(pattern)
    enzyme_start_sites = [i.span()[0] for i in P.finditer(text)]
    return enzyme_start_sites

#构建BAC文库(基于酶切位点)
def constructBACLibraryByRE(genome,enzyme='AT',plates=1,mu=300,sigma=20):
    BACs = []
    genome_len = len(genome)
    BACs_index = []
    enzyme_start_sites = alignment(enzyme, genome)
    while True:
        start_indexs = [random.choice(enzyme_start_sites) for _ in range(plates*384)] #获得BAC的酶切前末端
        appo_lengths = [int(i) for i in np.random.normal(mu,sigma,plates*384)]#生成符合正态分布的随机整数
        appo_end_indexs = [start_indexs[i] + appo_lengths[i] for i in range(len(start_indexs))]
        end_indexs = [random.choice(find_neighbor(i,enzyme_start_sites)) for i in appo_end_indexs] #获取BAC的另一酶切末端
        BACs_index.extend([[start_indexs[i],end_indexs[i]] for i in range(len(start_indexs)) if end_indexs[i] < genome_len])
        if len(BACs_index) >= 384*plates:   #如果末端过滤后产生的BAC数少于需得到的数，则进入循环，继续产生BAC
            break
    BACs = [BAC_front + genome[i[0]:i[1]] + BAC_behind for i in BACs_index[:(plates*384)]]  #取需要的BAC数，并提取序列
    return BACs


def plateIDs(plates=1):
    rownames = string.ascii_uppercase[0:16]
    colnames = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10',
                '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                '21', '22', '23', '24']
    plate = [str(row + col) for row in rownames for col in colnames]

    plates = [str(str(num)+i) for num in range(1,plates+1) for i in plate]
    return plates

# 将字典中的BAC信息以fasta格式保存到文件
def dict_to_fasta(filename,dict):
    with open(filename,'w') as f:
        for i in dict:
            f.write(str('>' + i+'\n'))
            f.write(dict[i]+'\n')



def parse_pool_identity(x_axis=None, y_axis=None, plates_layout=None):
    # create a 384-plate, generating the identity of each of BAC.
    def one_plate(plate_id=""):
        rownames = string.ascii_uppercase[0:16]
        colnames = ["01", "02", "03", "04", "05", "06", "07", "08", "09", '10',
                    '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                    '21', '22', '23', '24']
        plate_dict = dict([(i,[]) for i in colnames])
        for col in colnames:
            for row in rownames:
                plate_dict[col].append(str(plate_id) + str(row) + str(col))
        plate_DataFrame = pd.DataFrame(plate_dict, index=[i for i in rownames])
        return plate_DataFrame
    # create the number of 384-plate in plates_matrix layout, generating the identity of each of BAC.
    def plates(plates_layout=None):
        entry_matrix = pd.DataFrame()
        for i in plates_layout:
            row_matix = pd.concat([one_plate(j) for j in i], axis=1)
            entry_matrix = pd.concat([entry_matrix, row_matix], axis=0)
        entry_matrix.index = ["X"+str(i) for i in range(1, entry_matrix.shape[0]+1)]
        entry_matrix.columns = ["Y"+str(i) for i in range(1, entry_matrix.shape[1]+1)]
        return entry_matrix

    if plates_layout == None:
        return one_plate()
    else:
        return plates(plates_layout)



def main():
	raw_genome = readGenome(options.input_file)    # CHANGE POS#1

	#gap filling
	genome = substitute_for_Ns(raw_genome)

	# 以fasta格式保存基因组序列
	genome_dict_to_fasta(filename='genome.fa',dict={'genome':genome})


	# 构建BAC文库(基于酶切位点)    
	bac = constructBACLibraryByRE(genome,enzyme='AAGCTT',plates=24,mu=120000,sigma=10000)     # CHANGE POS#2


	id = plateIDs(plates=24)


	# 将ID分别赋给BAC序列，生成字典
	BAC_library = {}
	for i in range(len(id)):
	    BAC_library[id[i]] = bac[i]


	#保存信息
	dict_to_fasta(filename='bac_library.fa',dict=BAC_library)		# CHANGE POS#3

	# 获取行列pool序列
	layout_id = parse_pool_identity(plates_layout=[[1, 2, 7, 8],
	                     [3, 4, 9, 10],
	                     [5, 6, 11,12],
	                     [13,14,19,20],
	                     [15,16,21,22],
	                     [17,18,23,24]])


	os.makedirs('pool')
	for i in range(96):
	# 行池
	    pool_x = {j:BAC_library[j] for j in list(layout_id.iloc[i,:])}
	    dict_to_fasta(filename=str('./pool/X'+str(i)+'.fasta'), dict=pool_x)
	# 列池
	    pool_y = {k:BAC_library[k] for k in list(layout_id.iloc[:,i])}
	    dict_to_fasta(filename=str('./pool/Y'+str(i)+'.fasta'), dict=pool_y)

if __name__ == '__main__':
    main()
