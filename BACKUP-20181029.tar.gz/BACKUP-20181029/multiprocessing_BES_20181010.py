import pandas as pd
from gresource.plate import parse_pool_identity, flatten

layout_id = parse_pool_identity(plates_layout=[['1', '2', '7', '8'],
                     ['3', '4', '9', '10'],
                     ['5', '6', '11','12'],
                     ['13','14','19','20'],
                     ['15','16','21','22'],
                     ['17','18','23','24']])



from HTSeq import FastaReader
import os


handle_file_valid = open('BES_valid.fasta','w')
handle_file_invalid = open('BES_invalid.fasta', 'w')
handle_file = open('BES_ALL.fasta','w+')

BES_library_0 = {} # initial dict



for i in layout_id.index:
    for j in layout_id.columns:
        query = j
        target = i
        BAC_id = layout_id.loc[i,j]
        os.system('python ~/software/toolkits/find_overlap_sequence_by_blat_20180917.py -q ../3_trimmed_pool/%s_BES.fasta -t ../3_trimmed_pool/%s_BES.fasta -o BES_%s.fasta' % (query, target, BAC_id))
        
        #read  BES to dict
        if os.path.exists(str('BES_' + BAC_id + '.fasta')) == False:
            os.system('touch BES_%s.fasta' % (BAC_id))
        BES_library_0[BAC_id] = [ i for i in FastaReader(str('BES_' + BAC_id + '.fasta'))]



# eccept false passitive
for i in range(layout_id.shape[0]):
    for j in range(layout_id.shape[1]):
        print(i)
        print(j)
        this = layout_id.iloc[i, j]
        if len(BES_library_0[this]) > 2 :

            X_ids_except_this = [k for k in layout_id.iloc[4, :] if k !=  this]
            Y_ids_except_this = [k for k in layout_id.iloc[:, 94] if k != this]

            X_contigs_except_this = [k.name for k in flatten([BES_library_0[i][1::2] for i in X_ids_except_this])]
            Y_contigs_except_this = [k.name for k in flatten([BES_library_0[i][::2] for i in Y_ids_except_this])]

            print(BES_library_0[this])
            del_index = []
            for m in  range(int(len(BES_library_0[this])/2)):
                if BES_library_0[this][m*2 +1].name in X_contigs_except_this and BES_library_0[this][m*2].name in Y_contigs_except_this :
                    del_index.append(m*2+1)
                    del_index.append(m*2)
            BES_library_0[this] = [v for index , v in enumerate(BES_library_0[this]) if index not in del_index]

            print(BES_library_0[this])

        with open('BES_'+ this + '_1.fasta', 'w') as handle:
            for k in BES_library_0[this]:
                k.write_to_fasta_file(handle)





handle_file_valid = open('BES_valid.fasta','w')
handle_file_invalid = open('BES_invalid.fasta', 'w')
handle_file = open('BES_ALL.fasta','w+')

for i in layout_id.index:
    for j in layout_id.columns:
        query = j
        target = i
        BAC_id = layout_id.loc[i,j]
        os.system('cap3 BES_%s_1.fasta > BES_%s_1.fasta.log' % (BAC_id, BAC_id))
        os.system('rm BES_%s_1.fasta.cap.ace' % (BAC_id))
        os.system('rm BES_%s_1.fasta.cap.info' % (BAC_id))
        os.system('rm BES_%s_1.fasta.cap.singlets' % (BAC_id))
        os.system('rm BES_%s_1.fasta.cap.contigs.qual' % (BAC_id))
        os.system('rm BES_%s_1.fasta.cap.contigs.links' % (BAC_id))
        os.system('rm BES_%s_1.fasta.log' % (BAC_id))

        if os.path.exists('BES_%s_1.fasta.cap.contigs' %(BAC_id)):
            clone_list = [k for k in FastaReader('BES_%s_1.fasta.cap.contigs' %(BAC_id))]
            if len(clone_list) ==1 :
                clone_list[0].name = BAC_id
                clone_list[0].write_to_fasta_file(handle_file)

                clone_list[0].write_to_fasta_file(handle_file_valid)
            elif len(clone_list) > 1:
                for l in range(len(clone_list)):
                    clone_list[l].name = BAC_id + '_'+ str(l+1)
                    clone_list[l].write_to_fasta_file(handle_file)

                    clone_list[l].write_to_fasta_file(handle_file_invalid)

handle_file.close()
handle_file_valid.close()
handle_file_invalid.close()
